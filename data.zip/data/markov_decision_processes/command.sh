wget "https://www.sciencedirect.com/topics/computer-science/markov-decision-process" -O ./files/0_positive --no-check-certificate 
wget "https://towardsdatascience.com/understanding-the-markov-decision-process-mdp-8f838510f150" -O ./files/1_positive --no-check-certificate 
wget "http://incompleteideas.net/book/first/ebook/node33.html" -O ./files/2_positive --no-check-certificate 
wget "https://m-elsersy96.medium.com/reinforcement-learning-demystified-markov-decision-processes-part-1-bf00dda41690" -O ./files/3 --no-check-certificate 
wget "https://www.geeksforgeeks.org/markov-decision-process/" -O ./files/4 --no-check-certificate 
wget "https://deepai.org/machine-learning-glossary-and-terms/markov-decision-process" -O ./files/5_positive --no-check-certificate 
wget "https://towardsdatascience.com/what-is-a-markov-decision-process-anyways-bdab65fd310c" -O ./files/6_positive --no-check-certificate 
wget "https://en.wikipedia.org/wiki/Markov_decision_process" -O ./files/7_positive --no-check-certificate 
