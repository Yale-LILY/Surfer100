wget "https://www.investopedia.com/terms/n/normaldistribution.asp" -O ./files/0_positive
wget "https://www.itl.nist.gov/div898/handbook/eda/section3/eda3661.htm" -O ./files/1
wget "https://mathworld.wolfram.com/NormalDistribution.html" -O ./files/2
wget "https://www.mathsisfun.com/data/standard-normal-distribution.html" -O ./files/3
wget "https://www.britannica.com/topic/normal-distribution" -O ./files/4_positive
wget "https://www.khanacademy.org/math/statistics-probability/modeling-distributions-of-data/normal-distributions-library/a/normal-distributions-review" -O ./files/5
wget "https://www.statisticshowto.com/probability-and-statistics/normal-distributions/" -O ./files/6
wget "https://statisticsbyjim.com/basics/normal-distribution/" -O ./files/7_positive
