wget "https://tkipf.github.io/graph-convolutional-networks/" -O ./files/0_positive
wget "https://towardsdatascience.com/understanding-graph-convolutional-networks-for-node-classification-a2bfdb7aba7b" -O ./files/1_positive
wget "https://towardsdatascience.com/graph-convolutional-networks-deep-99d7fee5706f" -O ./files/2_positive
wget "https://jonathan-hui.medium.com/graph-convolutional-networks-gcn-pooling-839184205692" -O ./files/3
wget "https://theaisummer.com/graph-convolutional-networks/" -O ./files/4
wget "https://perfectial.com/blog/graph-neural-networks-and-graph-convolutional-networks/" -O ./files/5 --no-check-certificate
