wget "https://www.ibm.com/cloud/learn/unsupervised-learning" -O ./files/0_positive
wget "https://towardsdatascience.com/unsupervised-learning-and-data-clustering-eeecb78b422a" -O ./files/1
wget "https://towardsdatascience.com/unsupervised-learning-and-data-clustering-eeecb78b422a" -O ./files/2
wget "https://deepai.org/machine-learning-glossary-and-terms/unsupervised-learning" -O ./files/3
wget "https://www.guru99.com/unsupervised-machine-learning.html" -O ./files/4
wget "https://machinelearningmastery.com/supervised-and-unsupervised-machine-learning-algorithms/" -O ./files/5
wget "https://www.datarobot.com/wiki/unsupervised-machine-learning/" -O ./files/6
wget "https://deepmind.com/blog/article/unsupervised-learning" -O ./files/7_positive
