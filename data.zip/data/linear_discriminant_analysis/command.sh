wget "https://sebastianraschka.com/Articles/2014_python_lda.html" -O ./files/0_positive
wget "https://towardsdatascience.com/linear-discriminant-analysis-explained-f88be6c1e00b" -O ./files/1_positive
wget "https://machinelearningmastery.com/linear-discriminant-analysis-for-machine-learning/" -O ./files/2_positive
wget "https://www.analyticsvidhya.com/blog/2021/08/a-brief-introduction-to-linear-discriminant-analysis/" -O ./files/3
wget "https://www.knowledgehut.com/blog/data-science/linear-discriminant-analysis-for-machine-learning" -O ./files/4
wget "https://www.digitalvidya.com/blog/linear-discriminant-analysis/" -O ./files/5
wget "https://medium.com/@srishtisawla/linear-discriminant-analysis-d38decf48105" -O ./files/6
wget "https://www.section.io/engineering-education/linear-discriminant-analysis/" -O ./files/7
