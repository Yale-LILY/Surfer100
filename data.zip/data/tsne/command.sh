wget "https://scikit-learn.org/stable/modules/generated/sklearn.manifold.TSNE.html" -O ./files/0_positive
wget "https://lvdmaaten.github.io/tsne/" -O ./files/1_positive
wget "https://distill.pub/2016/misread-tsne/" -O ./files/2_positive
wget "https://towardsdatascience.com/an-introduction-to-t-sne-with-python-example-5a3a293108d1?gi=6e92aef9ab02" -O ./files/3
wget "https://www.datatechnotes.com/2020/11/tsne-visualization-example-in-python.html" -O ./files/4
wget "https://towardsdatascience.com/t-distributed-stochastic-neighbor-embedding-t-sne-bb60ff109561?gi=69f8f3690a2c" -O ./files/5
wget "https://www.analyticsvidhya.com/blog/2017/01/t-sne-implementation-r-python/" -O ./files/6
