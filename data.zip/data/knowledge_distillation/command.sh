wget "https://towardsdatascience.com/knowledge-distillation-simplified-dd4973dbc764" -O ./files/0_positive
wget "https://intellabs.github.io/distiller/knowledge_distillation.html" -O ./files/1_positive
wget "https://www.microsoft.com/en-us/research/blog/three-mysteries-in-deep-learning-ensemble-knowledge-distillation-and-self-distillation/" -O ./files/2
wget "https://keras.io/examples/vision/knowledge_distillation/" -O ./files/3_positive
wget "https://en.wikipedia.org/wiki/Knowledge_distillation" -O ./files/4_positive
wget "https://blog.floydhub.com/knowledge-distillation/" -O ./files/5
