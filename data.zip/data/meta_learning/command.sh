wget "https://lilianweng.github.io/lil-log/2018/11/30/meta-learning.html" -O ./files/0_positive
wget "https://machinelearningmastery.com/meta-learning-in-machine-learning/" -O ./files/1_positive
wget "https://en.wikipedia.org/wiki/Meta_learning_(computer_science)" -O ./files/2_positive
wget "https://research.aimultiple.com/meta-learning/" -O ./files/3
wget "https://www.unite.ai/what-is-meta-learning/" -O ./files/4
wget "https://meta-learning.fastforwardlabs.com/" -O ./files/5
wget "https://www.section.io/engineering-education/meta-learning/" -O ./files/6
wget "https://medium.com/huggingface/from-zero-to-research-an-introduction-to-meta-learning-8e16e677f78a" -O ./files/7
