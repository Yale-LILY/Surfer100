wget "http://www.onmyphd.com/?p=kkt.karush.kuhn.tucker" -O ./files/0
wget "http://apmonitor.com/me575/index.php/Main/KuhnTucker" -O ./files/1_positive
wget "https://bookdown.org/edxu96/matrixoptim/kkt-conditions.html" -O ./files/2_positive
wget "https://towardsdatascience.com/optimization-stories-kkt-conditions-f86aea4fb6c2" -O ./files/3_positive
wget "https://medium.com/analytics-vidhya/karuch-kuhn-tucker-kkt-conditions-16057fcdb34b" -O ./files/4
wget "https://en.wikipedia.org/wiki/Karush%E2%80%93Kuhn%E2%80%93Tucker_conditions" -O ./files/5_positive
