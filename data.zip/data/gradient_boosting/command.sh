wget "https://machinelearningmastery.com/gentle-introduction-gradient-boosting-algorithm-machine-learning/" -O ./files/0_positive
wget "https://towardsdatascience.com/understanding-gradient-boosting-machines-9be756fe76ab" -O ./files/1
wget "https://www.frontiersin.org/articles/10.3389/fnbot.2013.00021/full" -O ./files/2_positive
wget "https://www.analyticsvidhya.com/blog/2021/04/how-the-gradient-boosting-algorithm-works/" -O ./files/3_positive
wget "https://www.displayr.com/gradient-boosting-the-coolest-kid-on-the-machine-learning-block/" -O ./files/4_positive
wget "https://blog.mlreview.com/gradient-boosting-from-scratch-1e317ae4587d" -O ./files/5
wget "https://explained.ai/gradient-boosting/" -O ./files/6
wget "https://c3.ai/glossary/data-science/gradient-boosted-decision-trees-gbdt/" -O ./files/7_positive
