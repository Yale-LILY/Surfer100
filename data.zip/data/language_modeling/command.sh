wget "https://machinelearningmastery.com/statistical-language-modeling-and-neural-language-models/" -O ./files/0_positive
wget "https://towardsdatascience.com/the-beginners-guide-to-language-models-aa47165b57f9" -O ./files/1_positive
wget "https://lena-voita.github.io/nlp_course/language_modeling.html" -O ./files/2
wget "http://www.cs.columbia.edu/~mcollins/lm-spring2013.pdf" -O ./files/3
wget "https://www.analyticsvidhya.com/blog/2019/08/comprehensive-guide-language-model-nlp-python-code/" -O ./files/4
wget "https://insights.daffodilsw.com/blog/what-are-language-models-in-nlp" -O ./files/5_positive
