wget "https://www.sciencedirect.com/science/article/pii/S1532046412001712" -O ./files/0_positive
wget "https://www.nature.com/articles/nrg3337" -O ./files/1_positive
wget "https://link.springer.com/chapter/10.1007/978-3-662-43968-5_16" -O ./files/2
wget "https://bmcbioinformatics.biomedcentral.com/articles/10.1186/s12859-019-2607-x" -O ./files/3
wget "https://mitpress.mit.edu/books/mining-biomedical-literature" -O ./files/4
wget "https://medium.com/@Petuum/applying-neural-networks-to-biomedical-text-mining-fe655270c12" -O ./files/5
