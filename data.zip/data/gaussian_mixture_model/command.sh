wget "https://scikit-learn.org/stable/modules/mixture.html" -O ./files/0_positive
wget "https://towardsdatascience.com/gaussian-mixture-models-explained-6986aaf5a95" -O ./files/1_positive
wget "https://brilliant.org/wiki/gaussian-mixture-model/" -O ./files/2_positive
wget "https://jakevdp.github.io/PythonDataScienceHandbook/05.12-gaussian-mixtures.html" -O ./files/3
wget "https://www.analyticsvidhya.com/blog/2019/10/gaussian-mixture-models-clustering/" -O ./files/4
wget "https://deepai.org/machine-learning-glossary-and-terms/gaussian-mixture-models" -O ./files/5
wget "https://en.wikipedia.org/wiki/Mixture_model" -O ./files/6_positive
