wget "https://machinelearningmastery.com/linear-regression-for-machine-learning/" -O ./files/0_positive
wget "https://scikit-learn.org/stable/modules/generated/sklearn.linear_model.LinearRegression.html" -O ./files/1
wget "http://www.stat.yale.edu/Courses/1997-98/101/linreg.htm" -O ./files/2_positive
wget "https://towardsdatascience.com/linear-regression-detailed-view-ea73175f6e86" -O ./files/3
wget "https://sphweb.bumc.bu.edu/otlt/MPH-Modules/BS/R/R5_Correlation-Regression/R5_Correlation-Regression5.html" -O ./files/4
wget "https://www.ibm.com/topics/linear-regression" -O ./files/5_positive
wget "https://www.statisticssolutions.com/free-resources/directory-of-statistical-analyses/what-is-linear-regression/" -O ./files/6_positive
wget "https://www.statisticshowto.com/probability-and-statistics/regression-analysis/find-a-linear-regression-equation/" -O ./files/7
