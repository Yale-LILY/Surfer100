wget "https://paperswithcode.com/task/text-simplification" -O ./files/0_positive
wget "http://nlpprogress.com/english/simplification.html" -O ./files/1_positive
wget "https://www.grammarly.com/blog/engineering/text-simplification-by-tagging/" -O ./files/2
wget "https://www.w3.org/WAI/GL/task-forces/coga/wiki/Text_Simplification" -O ./files/3_positive
wget "https://en.wikipedia.org/wiki/Text_simplification" -O ./files/4
wget "https://cisl.cast.org/research/automated-text-simplification" -O ./files/5_positive
