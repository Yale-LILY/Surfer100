wget "http://www.scholarpedia.org/article/Radial_basis_function" -O ./files/0_positive
wget "http://www.di.fc.ul.pt/~jpn/r/rbf/rbf.html" -O ./files/1
wget "https://deepai.org/machine-learning-glossary-and-terms/radial-basis-function" -O ./files/2_positive
wget "https://towardsdatascience.com/radial-basis-functions-neural-networks-all-we-need-to-know-9a88cc053448" -O ./files/3
wget "https://docs.juliahub.com/ADCME/b8Ld2/0.6.2/rbf/" -O ./files/4_positive
wget "https://en.wikipedia.org/wiki/Radial_basis_function" -O ./files/5_positive
