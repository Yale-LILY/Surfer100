wget "https://analyticsindiamag.com/guide-to-abstract-meaning-representationamr-to-text-with-tensorflow/" -O ./files/0_positive
wget "https://medium.com/@sroukos/semantic-parsing-using-abstract-meaning-representation-95242518a380" -O ./files/1
wget "https://www.cs.cornell.edu/courses/cs6740/2019fa/handouts/lec26-handout.pdf" -O ./files/2
wget "https://github.com/nschneid/amr-tutorial/raw/master/slides/1a-tutorial-intro.pdf" -O ./files/3_positive
wget "https://github.com/nschneid/amr-tutorial/raw/master/slides/2-algorithms.pdf" -O ./files/4_positive
