'''
This is to test url and get cmd for downloading
'''

import os,sys
import validators


path_now = os.getcwd()
print("Current working directory: {0}".format(path_now))

used=[]
with open('links_used.txt') as f:
    count = 0
    for line in f.readlines():
        line = line.strip()
        if len(line) > 5:
            valid = validators.url(line)
            if valid:
                used.append(line)
            
# read in links
urls = []
with open('links.txt') as f, open('command.sh','w') as w:
    count = 0
    for line in f.readlines():
        line = line.strip()
        if len(line)>5:
            valid = validators.url(line)
            if valid:
                if line in used:
                    w.write('wget \"' + line + '\"' + " -O ./files/" + str(count) + '_positive\n')
                else:
                    w.write('wget \"'+line+'\"'+" -O ./files/"+str(count)+'\n')
                count += 1

print ('Please run command.sh to download documents')

