wget "https://towardsdatascience.com/byte-pair-encoding-the-dark-horse-of-modern-nlp-eb36c7df4f10" -O ./files/0_positive
wget "https://leimao.github.io/blog/Byte-Pair-Encoding/" -O ./files/1_positive
wget "https://rutumulkar.com/blog/2021/byte-pair-encoding/" -O ./files/2_positive
wget "https://www.freecodecamp.org/news/evolution-of-tokenization/" -O ./files/3_positive
wget "https://blog.floydhub.com/tokenization-nlp/#bpe" -O ./files/4_positive
wget "https://iq.opengenus.org/byte-pair-encoding/" -O ./files/5_positive
wget "https://d2l.ai/chapter_natural-language-processing-pretraining/subword-embedding.html" -O ./files/6_positive
wget "https://huggingface.co/transformers/tokenizer_summary.html#byte-pair-encoding-bpe" -O ./files/7_positive
