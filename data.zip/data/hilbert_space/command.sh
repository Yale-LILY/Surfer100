wget "https://www.quantiki.org/wiki/hilbert-spaces" -O ./files/0_positive
wget "https://www.britannica.com/science/Hilbert-space" -O ./files/1_positive
wget "https://medium.com/@brcsomnath/hilbert-space-7a36e3badac2" -O ./files/2_positive
wget "https://brilliant.org/wiki/hilbert-space/" -O ./files/3
wget "https://encyclopediaofmath.org/wiki/Hilbert_space" -O ./files/4
wget "https://proofwiki.org/wiki/Definition:Hilbert_Space" -O ./files/5
