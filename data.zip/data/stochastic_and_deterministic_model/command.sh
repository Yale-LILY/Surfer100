wget "https://www4.stat.ncsu.edu/~gross/BIO560%20webpage/slides/Jan102013.pdf" -O ./files/0_positive
wget "https://www.researchgate.net/post/What-is-the-difference-among-Deterministic-model-Stochastic-model-and-Hybrid-model" -O ./files/1
wget "https://www.statisticshowto.com/stochastic-model/" -O ./files/2
wget "https://blog.ev.uk/stochastic-vs-deterministic-models-understand-the-pros-and-cons" -O ./files/3_positive
wget "https://www.seos-project.eu/modelling/modelling-c07-p01.html" -O ./files/4_positive
wget "https://machinelearningmastery.com/stochastic-in-machine-learning/" -O ./files/5_positive
