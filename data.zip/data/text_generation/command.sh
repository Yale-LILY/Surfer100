wget "https://medium.com/deep-learning-with-keras/fundamentals-of-text-generation-745d66238a1f" -O ./files/0_positive
wget "https://medium.com/sciforce/a-comprehensive-guide-to-natural-language-generation-dd63a4b6e548" -O ./files/1_positive
wget "https://www.marketingaiinstitute.com/blog/the-beginners-guide-to-using-natural-language-generation-to-scale-content-marketing" -O ./files/2_positive
wget "https://research.aimultiple.com/nlg/" -O ./files/3_positive
wget "https://bernardmarr.com/what-really-is-natural-language-generation-and-processing/" -O ./files/4
wget "https://www.yellowfinbi.com/blog/2021/01/what-is-natural-language-generation" -O ./files/5
wget "https://automatedinsights.com/blog/the-ultimate-guide-to-natural-language-generation/" -O ./files/6
