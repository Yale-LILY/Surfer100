import sys

fname = sys.argv[1]
outfname = sys.argv[2]
with open(fname) as inputf, open(outfname, "w") as outputf:
    for count, line in enumerate(inputf):
        if "arxiv" in line:
            print(f"{count}\t{line} looks like an arxiv link. You need to download that by hand!")
            continue
        outputf.write(f'wget "{line.strip()}" -O ./files/{count}\n')

