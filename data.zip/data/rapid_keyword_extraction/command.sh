wget "https://monkeylearn.com/keyword-extraction/" -O ./files/0
wget "https://towardsdatascience.com/keyword-extraction-methods-the-overview-35557350f8bb" -O ./files/1_positive
wget "https://medium.datadriveninvestor.com/rake-rapid-automatic-keyword-extraction-algorithm-f4ec17b2886c" -O ./files/2_positive
wget "https://www.airpair.com/nlp/keyword-extraction-tutorial" -O ./files/3
wget "https://towardsdatascience.com/extracting-keyphrases-from-text-rake-and-gensim-in-python-eefd0fad582f" -O ./files/4
wget "https://www.analyticsvidhya.com/blog/2021/10/rapid-keyword-extraction-rake-algorithm-in-natural-language-processing/" -O ./files/5
wget "https://amitness.com/keyphrase-extraction/" -O ./files/6_positive
