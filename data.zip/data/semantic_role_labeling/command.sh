wget "https://aclanthology.org/R19-1073.pdf" -O ./files/0
wget "https://web.stanford.edu/~jurafsky/slp3/slides/22_SRL.pdf" -O ./files/1_positive
wget "http://nlpprogress.com/english/semantic_role_labeling.html" -O ./files/2_positive
wget "https://paperswithcode.com/task/semantic-role-labeling" -O ./files/3
wget "https://natural-language-understanding.fandom.com/wiki/Semantic_role_labeling" -O ./files/4
wget "https://aclanthology.org/N16-1019.pdf" -O ./files/5
wget "https://orbifold.net/default/what-is-semantic-role-labeling/" -O ./files/6
wget "https://devopedia.org/semantic-role-labelling" -O ./files/7_positive
