wget "http://www.scholarpedia.org/article/Word_sense_disambiguation" -O ./files/0_positive
wget "https://www.tutorialspoint.com/natural_language_processing/natural_language_processing_word_sense_disambiguation.htm" -O ./files/1_positive
wget "https://towardsdatascience.com/a-simple-word-sense-disambiguation-application-3ca645c56357" -O ./files/2
wget "https://www.oxfordhandbooks.com/view/10.1093/oxfordhb/9780199573691.001.0001/oxfordhb-9780199573691-e-28" -O ./files/3_positive
wget "https://web.stanford.edu/~jurafsky/slp3/slides/Chapter18.wsd.pdf" -O ./files/4
wget "https://onlinelibrary.wiley.com/doi/full/10.1111/j.1749-818X.2009.00131.x" -O ./files/5_positive
wget "https://lhncbc.nlm.nih.gov/ii/areas/word-sense-disambiguation.html" -O ./files/6
wget "https://www.fosteropenscience.eu/content/word-sense-disambiguation" -O ./files/7
