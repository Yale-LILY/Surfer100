wget "https://medium.com/tech-that-works/maximal-marginal-relevance-to-rerank-results-in-unsupervised-keyphrase-extraction-22d95015c7c5" -O ./files/0_positive
wget "https://sites.google.com/site/nirajatweb/home/technical_and_coding_stuff/maximal-marginal-relevance" -O ./files/1_positive
wget "https://opensourcelibs.com/lib/nlp-extractive-news-summarization-using-mmr" -O ./files/2_positive
wget "https://www.cl.cam.ac.uk/teaching/1617/NLP/slides10.pdf" -O ./files/3
wget "https://towardsdatascience.com/keyword-extraction-with-bert-724efca412ea" -O ./files/4_positive
wget "https://nlp.stanford.edu/IR-book/pdf/08eval.pdf" -O ./files/5
