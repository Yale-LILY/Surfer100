wget "https://iq.opengenus.org/multilingual-bert/" -O ./files/0_positive
wget "https://ai.googleblog.com/2020/08/language-agnostic-bert-sentence.html" -O ./files/1_positive
wget "https://techxplore.com/news/2021-02-multilingual-bert-encode-grammatical-features.html" -O ./files/2_positive
wget "https://peltarion.com/blog/data-science/a-deep-dive-into-multilingual-nlp-models" -O ./files/3_positive
