wget "https://paperswithcode.com/method/vision-transformer" -O ./files/0_positive
wget "https://en.wikipedia.org/wiki/Vision_transformer" -O ./files/1_positive
wget "https://theaisummer.com/vision-transformer/" -O ./files/2
wget "https://viso.ai/deep-learning/vision-transformer-vit/" -O ./files/3_positive
wget "https://ai.googleblog.com/2020/12/transformers-for-image-recognition-at.html" -O ./files/4_positive
wget "https://towardsdatascience.com/vision-transformers-in-pytorch-43d13cb7ec7a" -O ./files/5
wget "https://ai.facebook.com/blog/multiscale-vision-transformers-an-architecture-for-modeling-visual-data/" -O ./files/6
