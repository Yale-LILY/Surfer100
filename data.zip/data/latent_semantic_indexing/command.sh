wget "https://www.searchenginejournal.com/latent-semantic-indexing-wont-help-seo/240705/" -O ./files/0_positive
wget "https://nlp.stanford.edu/IR-book/html/htmledition/latent-semantic-indexing-1.html" -O ./files/1_positive
wget "https://medium.com/@papillonbee/intuitive-understanding-to-latent-semantic-indexing-da340774ce23" -O ./files/2_positive
wget "https://www.oncrawl.com/technical-seo/what-is-latent-semantic-indexing/" -O ./files/3
wget "https://www.callrail.com/blog/what-is-latent-semantic-indexing/" -O ./files/4
wget "https://radimrehurek.com/gensim/models/lsimodel.html" -O ./files/5
wget "https://towardsdatascience.com/latent-semantic-analysis-deduce-the-hidden-topic-from-the-document-f360e8c0614b" -O ./files/6_positive
