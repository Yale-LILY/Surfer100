wget "https://www.semrush.com/blog/pagerank/" -O ./files/0_positive
wget "https://neo4j.com/docs/graph-data-science/current/algorithms/page-rank/" -O ./files/1_positive
wget "https://www.link-assistant.com/news/google-pagerank-algorithm.html" -O ./files/2
wget "https://towardsdatascience.com/pagerank-algorithm-fully-explained-dc794184b4af?gi=8e0ba14a6782" -O ./files/3_positive
wget "https://anvil.works/blog/search-engine-pagerank" -O ./files/4
wget "https://blog.majestic.com/company/understanding-googles-algorithm-how-pagerank-works/" -O ./files/5
wget "https://snap-stanford.github.io/cs224w-notes/network-methods/pagerank" -O ./files/6
