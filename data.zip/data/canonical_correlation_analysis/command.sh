wget "https://stats.idre.ucla.edu/r/dae/canonical-correlation-analysis/" -O ./files/0_positive
wget "https://online.stat.psu.edu/stat505/book/export/html/682" -O ./files/1_positive
wget "https://towardsdatascience.com/canonical-correlation-analysis-b1a38847219d" -O ./files/2_positive
wget "https://www.statisticssolutions.com/canonical-correlation/" -O ./files/3
wget "https://www.xlstat.com/en/solutions/features/canonical-correlation-analysis-ccora" -O ./files/4_positive
wget "https://cmdlinetips.com/2020/12/canonical-correlation-analysis-in-python/" -O ./files/5
wget "https://pubmed.ncbi.nlm.nih.gov/20733223/" -O ./files/6_positive
