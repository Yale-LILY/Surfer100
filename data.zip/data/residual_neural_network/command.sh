wget "https://towardsdatascience.com/introduction-to-resnets-c0a830a288a4" -O ./files/0_positive
wget "https://www.mygreatlearning.com/blog/resnet/" -O ./files/1_positive
wget "https://viso.ai/deep-learning/resnet-residual-neural-network/" -O ./files/2
wget "https://d2l.ai/chapter_convolutional-modern/resnet.html" -O ./files/3
wget "https://www.geeksforgeeks.org/introduction-to-residual-networks/" -O ./files/4
wget "https://medium.com/@waya.ai/deep-residual-learning-9610bb62c355" -O ./files/5_positive
wget "https://crossminds.ai/graphlist/residual-neural-network-resnet-ai-research-graph-60708a51c8663c4cfa875fc3/" -O ./files/6
