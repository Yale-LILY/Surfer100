wget "https://machinelearningmastery.com/what-is-semi-supervised-learning/" -O ./files/0_positive --no-check-certificate 
wget "https://bdtechtalks.com/2021/01/04/semi-supervised-machine-learning/" -O ./files/1_positive --no-check-certificate 
wget "https://medium.com/inside-machine-learning/placeholder-3557ebb3d470" -O ./files/2_positive --no-check-certificate 
wget "https://www.datarobot.com/wiki/semi-supervised-machine-learning/" -O ./files/3 --no-check-certificate 
wget "https://www.geeksforgeeks.org/ml-semi-supervised-learning/" -O ./files/4_positive --no-check-certificate 
wget "https://towardsdatascience.com/supervised-learning-but-a-lot-better-semi-supervised-learning-a42dff534781" -O ./files/5_positive --no-check-certificate 
wget "https://en.wikipedia.org/wiki/Semi-supervised_learning" -O ./files/6_positive --no-check-certificate 
